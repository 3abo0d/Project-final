package com.projectfinal.liquidglass;

import android.util.Log;
import de.robv.android.xposed.IXposedHookLoadPackage;
import de.robv.android.xposed.XC_MethodHook;
import de.robv.android.xposed.XposedBridge;
import de.robv.android.xposed.callbacks.XC_LoadPackage;
import java.lang.reflect.Method;

public final class ProjectFinalEntry implements IXposedHookLoadPackage {
    private static final String TAG = "PROJECT-FINAL";
    private static volatile boolean installed;

    @Override public void handleLoadPackage(XC_LoadPackage.LoadPackageParam lpparam) {
        if (!"com.android.systemui".equals(lpparam.packageName)) return;
        XposedBridge.log(TAG + ": loaded in SystemUI");
        tryHook(lpparam, "com.oplus.systemui.plugins.qs.OplusPanelViewPagerController",
                "loadQSPanelView", boolean.class);
        tryHook(lpparam, "com.oplus.systemui.plugins.qs.OplusPanelViewPagerController",
                "updateQSExpandFraction", float.class, boolean.class, boolean.class, float.class);
    }

    private void tryHook(XC_LoadPackage.LoadPackageParam p, String className,
                         String methodName, Class<?>... params) {
        try {
            Class<?> c = Class.forName(className, false, p.classLoader);
            Method m = c.getDeclaredMethod(methodName, params);
            m.setAccessible(true);
            XposedBridge.hookMethod(m, new XC_MethodHook() {
                @Override protected void afterHookedMethod(MethodHookParam param) {
                    if ("loadQSPanelView".equals(methodName)) {
                        Object result = param.getResult();
                        if (result instanceof android.view.View) {
                            GlassAttach.attach((android.view.View) result);
                        }
                    }
                    if ("updateQSExpandFraction".equals(methodName)) {
                        float fraction = ((Number)param.args[0]).floatValue();
                        Log.d(TAG, "QS fraction=" + fraction);
                        XposedBridge.log(TAG + ": QS fraction=" + fraction);
                    }
                }
            });
            XposedBridge.log(TAG + ": HOOK OK " + className + "." + methodName);
        } catch (Throwable t) {
            XposedBridge.log(TAG + ": HOOK FAIL " + className + "." + methodName + " " + t);
        }
    }
}
