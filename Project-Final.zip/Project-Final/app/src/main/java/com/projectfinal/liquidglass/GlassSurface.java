package com.projectfinal.liquidglass;

import android.content.Context;
import android.graphics.Canvas;
import android.graphics.RuntimeShader;
import android.graphics.Shader;
import android.graphics.Paint;
import android.view.View;
import android.os.Build;

/**
 * Renderer foundation. This first build intentionally renders a shader-based
 * glass material only; live backdrop capture/refraction is a subsequent milestone.
 */
final class GlassSurface extends View {
    private static final String AGSL =
        "uniform float2 resolution;" +
        "uniform float time;" +
        "half4 main(float2 p) {" +
        " float2 uv = p / resolution;" +
        " float2 c = abs(uv - 0.5) * 2.0;" +
        " float edge = smoothstep(1.0, 0.72, max(c.x, c.y));" +
        " float rim = exp(-max(0.0, min(min(uv.x,1.0-uv.x),min(uv.y,1.0-uv.y)))*34.0);" +
        " float sheen = pow(max(0.0, 1.0 - uv.y), 5.0);" +
        " half a = half(0.075 * edge);" +
        " half3 col = half3(0.72,0.86,1.0) * half(0.12*rim + 0.08*sheen);" +
        " return half4(col, a);" +
        "}";
    private RuntimeShader shader;
    private final Paint paint = new Paint(Paint.ANTI_ALIAS_FLAG);

    GlassSurface(Context context) {
        super(context);
        setLayerType(View.LAYER_TYPE_HARDWARE, null);
        if (Build.VERSION.SDK_INT >= 33) {
            try { shader = new RuntimeShader(AGSL); }
            catch (Throwable ignored) { shader = null; }
        }
    }

    @Override protected void onDraw(Canvas canvas) {
        super.onDraw(canvas);
        if (shader == null) return;
        shader.setFloatUniform("resolution", Math.max(1,getWidth()), Math.max(1,getHeight()));
        shader.setFloatUniform("time", 0f);
        paint.setShader(shader);
        canvas.drawRect(0, 0, getWidth(), getHeight(), paint);
    }
}
