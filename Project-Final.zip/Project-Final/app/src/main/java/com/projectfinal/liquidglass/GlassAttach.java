package com.projectfinal.liquidglass;

import android.view.View;
import android.view.ViewGroup;
import android.widget.FrameLayout;
import android.util.Log;

final class GlassAttach {
    private static final int VIEW_TAG = 0x50464C47;
    private GlassAttach() {}

    static void attach(View root) {
        try {
            if (!(root instanceof ViewGroup)) return;
            ViewGroup group = (ViewGroup) root;
            if (group.findViewWithTag(VIEW_TAG) != null) return;
            GlassSurface glass = new GlassSurface(root.getContext());
            glass.setTag(VIEW_TAG);
            glass.setImportantForAccessibility(View.IMPORTANT_FOR_ACCESSIBILITY_NO);
            glass.setClickable(false);
            glass.setFocusable(false);
            FrameLayout.LayoutParams lp = new FrameLayout.LayoutParams(
                    ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.MATCH_PARENT);
            if (group instanceof FrameLayout) {
                ((FrameLayout) group).addView(glass, lp);
            } else {
                Log.w("PROJECT-FINAL", "QS root is not FrameLayout; safe attach skipped: " + root.getClass());
                return;
            }
            Log.i("PROJECT-FINAL", "Glass surface attached to " + root.getClass().getName());
        } catch (Throwable t) {
            Log.e("PROJECT-FINAL", "attach failed", t);
        }
    }
}
