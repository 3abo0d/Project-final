# Project Final

A clean-room LSPosed prototype for investigating ColorOS 16 Quick Settings integration.

## Current status
- Android/Gradle project scaffold.
- LSPosed entry point scoped to `com.android.systemui`.
- Runtime hook attempts for the ColorOS classes/method signatures supplied in the project handoff.
- AGSL shader-backed glass surface foundation.
- GitHub Actions debug APK workflow.

## Important limitations
This is **not a finished Liquid Glass implementation**. The current shader draws a translucent highlight material; it does not yet sample the live backdrop, perform true background refraction, or replace ColorOS baked Fluid Glass resources. The hook signatures and return types must be validated on the target firmware. The attach code deliberately skips non-FrameLayout roots rather than risking a SystemUI crash.

Do not install on a daily-use device until the APK builds, the hook logs are checked, and a reversible runtime test is completed. Keep the existing known-good module available as a fallback.

## Build
Push this folder to a new GitHub repository named `Project-Final`. GitHub Actions builds `app-debug.apk` and publishes it as `Project-Final-debug`.

## Next engineering milestones
1. Confirm the actual `loadQSPanelView` return type and root class on the target ColorOS build.
2. Add a safe, reversible attach/detach lifecycle tied to the verified QS visibility callback.
3. Implement backdrop capture that excludes the glass view itself.
4. Feed the captured bitmap into AGSL and implement lens distortion/chromatic dispersion.
5. Replace one native tile material at a time, preserving native click/gesture handling.
6. Add runtime kill switch and validate shade animations, touch and memory use.
